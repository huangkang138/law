export type DigitalHumanEmotion =
  | 'idle'
  | 'welcome'
  | 'thinking'
  | 'talk_normal'
  | 'serious'
  | 'success'
  | 'error'
  | 'handoff';

export type ConversationRoute =
  | 'normal_chat' | 'labor_consultation' | 'labor_triage'
  | 'matter_interaction' | 'agent_continue' | 'workspace_guidance'
  | 'high_risk_handoff';

export interface DigitalHumanChatResponse {
  success: boolean;
  reply: string;
  intent: string;
  conversation_route?: ConversationRoute | null;
  emotion: DigitalHumanEmotion;
  confidence: number;
  route: string | null;
  route_label: string | null;
  session_id: string;
  decision: {
    route: ConversationRoute;
    confidence: number;
    reason_code: string;
  };
  action: {
    type:
      | 'reply_only' | 'ask_one_key_question' | 'create_matter'
      | 'guide_to_workspace' | 'start_agent' | 'continue_agent'
      | 'request_approval' | 'stop_for_risk';
    status: string;
    matter_id: string | null;
    run_id: string | null;
    question: string | null;
  };
  context: {
    matter_id: string | null;
    run_id: string | null;
    run_status: string | null;
    input_tokens_estimated: number;
  };
}

interface ApiErrorResponse {
  error?: string;
}

export interface DigitalHumanSessionSummary {
  id: string;
  title: string;
  created_at: string | null;
  updated_at: string | null;
}

export interface DigitalHumanHistoryMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  emotion?: DigitalHumanEmotion | null;
  created_at: string | null;
}

export interface ConversationPresentation {
  version: '1.0';
  state_key:
    | 'idle' | 'matter_ready' | 'preparing' | 'processing'
    | 'needs_jurisdiction' | 'needs_information' | 'blocked_authority'
    | 'needs_approval' | 'needs_human' | 'completed' | 'stopped' | 'unknown';
  headline: string;
  summary: string;
  requires_user_action: boolean;
  next_action: {
    type:
      | 'none' | 'open_workspace' | 'confirm_jurisdiction'
      | 'provide_information' | 'review_authority' | 'review_approval'
      | 'view_result' | 'restart';
    label: string;
  };
}

export type AgentRunStatus =
  | 'planning' | 'awaiting_jurisdiction' | 'awaiting_information'
  | 'executing' | 'observing' | 'verifying' | 'deciding' | 'retrying' | 'awaiting_approval'
  | 'blocked_authority' | 'replanning' | 'human_handoff'
  | 'completed' | 'failed' | 'cancelled';

export interface DigitalHumanAgentRun {
  // 后端持久化任务的完整 UI 快照；刷新后可按 run_id 重新获取。
  success: boolean;
  run_id: string;
  matter_id: string;
  status: AgentRunStatus;
  current_step_id: string | null;
  steps: Array<{
    id: string;
    name: string;
    status: string;
    tool_name: string | null;
    step_type: string | null;
    skip_reason: string | null;
    triggered_by_tags: string[];
    requires_approval: boolean;
    verification_policy_ids: string[];
    observation: Record<string, unknown> | null;
    verification: Record<string, unknown> | null;
    decision: Record<string, unknown> | null;
  }>;
  approval: { id: string; prompt: string; status: string } | null;
  task_type: string;
  domain_id: string | null;
  template_id: string | null;
  template_version: string | null;
  plan_id: string | null;
  plan_revision: number;
  replan_reason: string | null;
  dispute_tags: string[];
  composition_version: string | null;
  plan_version: number;
  missing_facts: string[];
  questions: string[];
  blocked_reason: string | null;
  final_artifact_ids: string[];
  max_steps: number;
  max_tool_calls: number;
  tool_call_count: number;
  budget_wallclock_seconds: number;
  budget_tokens: number;
  token_usage: number;
  budget_cost_cents: number;
  cost_cents: number;
  final_output: Record<string, unknown> | null;
  error_code: string | null;
}

export interface MatterMaterial {
  document_id: string;
  filename: string;
  content_hash: string;
  character_count: number;
  fragment_count: number;
}

export interface OrganizedMatterMaterial {
  filename: string;
  media_type: string;
  text: string;
  character_count: number;
}

export interface LocatedLegalFact {
  fact_id: string;
  fact_type: string;
  fact_text: string;
  confidence: number;
  material_ref: {
    document_id: string;
    fragment_id: string;
    start_offset: number;
    end_offset: number;
    page_number: number | null;
    quote: string;
  };
}

export interface MatterAnalysisResult {
  facts: LocatedLegalFact[];
  timeline: Array<{ date: string; fact_id: string; event: string }>;
  checklist: {
    available: Array<{ document_id: string; filename: string }>;
    missing: string[];
    located_fact_count: number;
    warning: string;
  };
}

export interface DigitalHumanMatterSummary {
  matter_id: string;
  session_id: string | null;
  title: string;
  goal: string;
  created_at: string | null;
  updated_at: string | null;
}

export interface DigitalHumanMatterDetail {
  matter_id: string;
  session_id: string | null;
  title: string;
  goal: string;
  jurisdiction: null | {
    country_code: string;
    subdivision_code: string | null;
    language: string;
    effective_at: string;
    confirmed_by_user: boolean;
  };
}

export interface DigitalHumanWorkspaceContext {
  session_id: string;
  workspace_version: number;
  matter: null | {
    matter_id: string;
    session_id: string;
    title: string;
    goal: string;
  };
  triage: LaborTriageSnapshot | null;
  run: DigitalHumanAgentRun | null;
  presentation: ConversationPresentation;
}

export interface LaborCompensationResult {
  compensation: number;
  monthly_salary: number;
  years: number;
  months: number;
  formula: string;
  calculation: string;
  warning: string;
}

export interface LaborDisputeWorkflow {
  matter_id: string;
  status: 'awaiting_information' | 'ready' | 'blocked_authority' | 'awaiting_draft_approval' | 'completed';
  facts: Record<string, unknown>;
  missing_facts: string[];
  questions: string[];
  plan: Array<{ name: string; status: string; questions?: string[] }>;
  warning?: string;
  deadline?: {
    rule_version: string;
    start_date: string;
    estimated_deadline: string | null;
    assumptions: string[];
    warnings: string[];
    manual_review_required: boolean;
  };
  authorities?: Array<{
    authority_id: string;
    title: string;
    provision: string | null;
    source_url: string;
    issuing_body: string;
    trust_level: string;
    version: string;
  }>;
  approval_prompt?: string;
}

export interface LaborRuleDecision {
  status: 'completed' | 'information_required' | 'authority_required';
  issue_tag: string;
  rule_version: string;
  assessment: string;
  missing_facts: string[];
  fact_refs: string[];
  evidence_refs: string[];
  authority_refs: string[];
  calculations: Record<string, unknown>;
  assumptions: string[];
  warnings: string[];
  manual_review_required: boolean;
  legal_conclusion: false;
}

export interface LaborAnalysisResult {
  status?: string;
  warning?: string;
  missing_rule_facts?: string[];
  deadline?: {
    estimated_deadline: string | null;
    assumptions: string[];
    warnings: string[];
    manual_review_required: boolean;
  };
  authorities?: Array<{
    authority_id: string;
    title: string;
    provision: string | null;
    source_url: string;
    issuing_body: string;
    trust_level: string;
    version: string;
    external_id?: string | null;
  }>;
  rule_decisions?: LaborRuleDecision[];
}

export interface LaborDisputeDraft {
  artifact_id: string;
  title: string;
  status: 'draft';
  content: string;
  authority_refs: string[];
}

export interface LaborFactSuggestions {
  matter_id: string;
  suggested_facts: Record<string, string | number | string[]>;
  fields: Array<{
    field: string;
    label: string;
    value: string | number | string[];
    confidence: number;
    sources: Array<{ document_id: string; fact_id: string | null; quote: string }>;
  }>;
  warning: string;
}

export type LaborTriageType =
  | 'simple_labor_consultation'
  | 'labor_relationship_assessment'
  | 'formal_labor_dispute'
  | 'non_labor_dispute'
  | 'high_risk_handoff';

export interface LaborTriageFacts {
  issue_domain: 'labor' | 'non_labor' | 'unknown';
  scenario_type:
    | 'school_arranged_internship' | 'independent_internship' | 'work_study'
    | 'part_time' | 'graduate_employment' | 'regular_employment' | 'other' | 'unknown';
  student_status: 'current_student' | 'graduating' | 'graduated' | 'not_student' | 'unknown';
  school_arranged: boolean | null;
  employment_intent: boolean | null;
  employer_qualified: boolean | null;
  paid_labor: boolean | null;
  management_control: boolean | null;
  business_integrated: boolean | null;
  regular_schedule: boolean | null;
  agreement_type: 'labor_contract' | 'internship_agreement' | 'service_agreement' | 'none' | 'unknown';
  claim_types: string[];
  urgent_risks: string[];
}

export interface LaborTriageResult {
  triage_type: LaborTriageType;
  relationship_status: 'not_assessed' | 'uncertain' | 'likely_established' | 'likely_not_established';
  dispute_tags: string[];
  basis: string[];
  missing_facts: string[];
  questions: string[];
  risk_level: 'low' | 'medium' | 'high';
  recommended_task_type: string | null;
  recommended_next_step: string;
  manual_review_required: boolean;
  rule_version: string;
  legal_conclusion: false;
  notice: string;
  scenario_type: LaborTriageFacts['scenario_type'];
  student_status: LaborTriageFacts['student_status'];
}

export interface LaborTriageSnapshot {
  matter_id: string;
  facts: LaborTriageFacts;
  result: LaborTriageResult;
  version: number;
}

export interface LaborAuthorityCatalog {
  status: 'ready' | 'degraded' | 'unavailable';
  count: number;
  authorities: Array<{
    authority_id: string; title: string; provision: string | null;
    source_url: string; issuing_body: string; trust_level: string;
    version: string; last_verified_at: string | null; external_id?: string | null;
  }>;
  governance: {
    status: 'ready' | 'degraded' | 'unavailable';
    provider: string;
    checked_at: string;
    expected_count: number;
    ready_count: number;
    pending_review_count: number;
    stale_count: number;
    missing_count: number;
    failed_count: number;
    sources: Array<{
      external_id: string;
      state: string;
      authority_id: string | null;
      version: string | null;
      fresh_until: string | null;
    }>;
    latest_sync: null | {
      run_id: string;
      status: string;
      trigger: string;
      requested_by: string | null;
      fetched_count: number;
      imported_count: number;
      unchanged_count: number;
      review_required_count: number;
      failed_count: number;
      error_code: string | null;
      started_at: string;
      completed_at: string | null;
    };
  };
}

const CLIENT_ID_KEY = 'yys-law-digital-human-client-id';

function getClientId(): string {
  const existing = window.localStorage.getItem(CLIENT_ID_KEY);
  if (existing?.startsWith('dhc_')) return existing;
  const value = `dhc_${crypto.randomUUID()}`;
  window.localStorage.setItem(CLIENT_ID_KEY, value);
  return value;
}

async function request(path: string, init: RequestInit = {}, timeoutMs = 45000) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  init.signal?.addEventListener('abort', abort, { once: true });
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(path, {
      ...init,
      credentials: 'include',
      signal: controller.signal,
      headers: {
        'X-Digital-Human-Client-ID': getClientId(),
        ...init.headers,
      },
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error('请求已取消或等待超时');
    }
    throw error;
  } finally {
    init.signal?.removeEventListener('abort', abort);
    window.clearTimeout(timer);
  }
}

async function readJson<T>(response: Response): Promise<T> {
  const data = (await response.json().catch(() => ({}))) as T & ApiErrorResponse;
  if (!response.ok) {
    throw new Error(data.error || '数字人服务暂时不可用');
  }
  return data;
}

export async function sendDigitalHumanMessage(
  question: string,
  sessionId: string | null,
  requestId: string,
  signal?: AbortSignal,
): Promise<DigitalHumanChatResponse> {
  const response = await request('/api/digital-human/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      question, request_id: requestId,
      ...(sessionId ? { session_id: sessionId } : {}),
    }), signal,
  });

  return readJson<DigitalHumanChatResponse>(response);
}

export type DigitalHumanStreamStatus = 'accepted' | 'thinking';

export interface DigitalHumanVoicePayload {
  seq: number;
  text: string;
  ttsMode: 'primary' | 'fallback';
  audioDataUrl: string | null;
  requestId: string;
}

export interface DigitalHumanStreamHandlers {
  onStatus?: (status: DigitalHumanStreamStatus, message?: string) => void;
  onDelta?: (text: string) => void;
  onVoice?: (payload: DigitalHumanVoicePayload) => void;
  onStreamFallback?: () => void;
}

export class DigitalHumanStreamError extends Error {
  code: string;
  retryable: boolean;

  constructor(payload: { error?: string; code?: string; retryable?: boolean }) {
    super(payload.error || '数字人服务暂时不可用');
    this.name = 'DigitalHumanStreamError';
    this.code = payload.code || 'STREAM_ERROR';
    this.retryable = Boolean(payload.retryable);
  }
}

interface SseEventBlock {
  event: string;
  data: string;
}

function parseSseBlock(block: string): SseEventBlock | null {
  let event = '';
  const dataLines: string[] = [];
  for (const line of block.split('\n')) {
    if (line.startsWith('event:')) {
      event = line.slice('event:'.length).trim();
    } else if (line.startsWith('data:')) {
      dataLines.push(line.slice('data:'.length).replace(/^ /, ''));
    }
  }
  if (!dataLines.length) return null;
  return { event, data: dataLines.join('\n') };
}

export async function sendDigitalHumanMessageStream(
  question: string,
  sessionId: string | null,
  requestId: string,
  handlers: DigitalHumanStreamHandlers,
  signal?: AbortSignal,
  voice = false,
): Promise<DigitalHumanChatResponse> {
  // SSE增量呈现：服务端完成解析、路由、安全校验和持久化后分块下发已验证回复；
  // voice=true 时按句附加 voice 事件（seq 递增，tts_mode 区分 primary/fallback）。
  const response = await request('/api/digital-human/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      question, request_id: requestId, voice,
      ...(sessionId ? { session_id: sessionId } : {}),
    }), signal,
  });
  if (!response.ok) {
    const data = (await response.json().catch(() => ({}))) as ApiErrorResponse;
    throw new Error(data.error || '数字人服务暂时不可用');
  }
  if (!response.body || typeof response.body.getReader !== 'function') {
    // 浏览器不支持流式读取：降级为普通请求，并明确提示而不是静默吞错。
    handlers.onStreamFallback?.();
    return sendDigitalHumanMessage(question, sessionId, requestId, signal);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let completed: DigitalHumanChatResponse | null = null;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let boundary = buffer.indexOf('\n\n');
      while (boundary >= 0) {
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const parsed = parseSseBlock(block);
        if (parsed) {
          const payload = JSON.parse(parsed.data) as Record<string, unknown>;
          if (parsed.event === 'status') {
            handlers.onStatus?.(
              payload.status as DigitalHumanStreamStatus,
              typeof payload.message === 'string' ? payload.message : undefined,
            );
          } else if (parsed.event === 'delta') {
            handlers.onDelta?.(typeof payload.text === 'string' ? payload.text : '');
          } else if (parsed.event === 'voice') {
            const audioB64 = typeof payload.audio_b64 === 'string' ? payload.audio_b64 : '';
            const mimeType = typeof payload.mime_type === 'string' ? payload.mime_type : 'audio/mp3';
            handlers.onVoice?.({
              seq: typeof payload.seq === 'number' ? payload.seq : 0,
              text: typeof payload.text === 'string' ? payload.text : '',
              ttsMode: payload.tts_mode === 'primary' ? 'primary' : 'fallback',
              audioDataUrl: audioB64
                ? `data:${mimeType};base64,${audioB64}`
                : null,
              requestId: typeof payload.request_id === 'string' ? payload.request_id : requestId,
            });
          } else if (parsed.event === 'completed') {
            completed = payload as unknown as DigitalHumanChatResponse;
          } else if (parsed.event === 'error') {
            throw new DigitalHumanStreamError(payload as {
              error?: string;
              code?: string;
              retryable?: boolean;
            });
          }
        }
        boundary = buffer.indexOf('\n\n');
      }
    }
  } catch (error) {
    if (error instanceof DigitalHumanStreamError) throw error;
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error('已停止等待回复');
    }
    if (error instanceof SyntaxError) {
      throw new Error('流式回复解析失败，请稍后重试');
    }
    throw error;
  } finally {
    reader.releaseLock();
  }
  if (!completed) {
    throw new Error('流式回复中断，未收到完整回答，请刷新后重试');
  }
  return completed;
}

export interface DigitalHumanCancelResult {
  success: boolean;
  cancelled: boolean;
  request_id: string;
  status: string | null;
}

export async function cancelDigitalHumanChatRequest(
  requestId: string,
): Promise<DigitalHumanCancelResult> {
  const response = await request('/api/digital-human/chat/cancel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ request_id: requestId }),
  });
  return readJson<DigitalHumanCancelResult>(response);
}

export async function resetDigitalHumanSession(sessionId: string): Promise<void> {
  const response = await request('/api/digital-human/reset', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_id: sessionId }),
  });

  await readJson<{ success: boolean }>(response);
}

export async function getDigitalHumanSessions(): Promise<DigitalHumanSessionSummary[]> {
  const response = await request('/api/digital-human/sessions');
  return (await readJson<{ success: boolean; sessions: DigitalHumanSessionSummary[] }>(response)).sessions;
}

export async function createDigitalHumanWorkspaceSession(): Promise<DigitalHumanWorkspaceContext> {
  const response = await request('/api/digital-human/sessions', {
    method: 'POST',
  });
  return readJson(response);
}

export async function getDigitalHumanMessages(sessionId: string): Promise<DigitalHumanHistoryMessage[]> {
  const response = await request(`/api/digital-human/sessions/${encodeURIComponent(sessionId)}/messages`);
  return (await readJson<{ success: boolean; messages: DigitalHumanHistoryMessage[] }>(response)).messages;
}

export async function getDigitalHumanWorkspace(
  sessionId: string,
): Promise<DigitalHumanWorkspaceContext> {
  const response = await request(
    `/api/digital-human/sessions/${encodeURIComponent(sessionId)}/workspace`,
  );
  return readJson(response);
}

export async function selectDigitalHumanWorkspaceMatter(
  sessionId: string,
  matterId: string | null,
  expectedVersion: number,
): Promise<DigitalHumanWorkspaceContext> {
  const response = await request(
    `/api/digital-human/sessions/${encodeURIComponent(sessionId)}/workspace`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        matter_id: matterId,
        expected_version: expectedVersion,
      }),
    },
  );
  return readJson(response);
}

export async function deleteDigitalHumanSession(sessionId: string): Promise<void> {
  const response = await request(`/api/digital-human/sessions/${encodeURIComponent(sessionId)}`, { method: 'DELETE' });
  await readJson<{ success: boolean }>(response);
}

export async function startDigitalHumanAgentRun(goal: string, sessionId: string | null): Promise<DigitalHumanAgentRun> {
  // 创建后端任务后，接口会同步推进到等待审批或终态。
  const response = await request('/api/digital-human/agent/runs', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ goal, ...(sessionId ? { session_id: sessionId } : {}) }),
  });
  return readJson<DigitalHumanAgentRun>(response);
}

export async function resumeDigitalHumanAgentRun(runId: string, approved: boolean): Promise<DigitalHumanAgentRun> {
  // approved 是显式用户决定，前端不能替用户默认确认。
  const response = await request(`/api/digital-human/agent/runs/${encodeURIComponent(runId)}/resume`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ approved }),
  });
  return readJson<DigitalHumanAgentRun>(response);
}

export async function cancelDigitalHumanAgentRun(runId: string): Promise<DigitalHumanAgentRun> {
  // 取消操作同时终止当前步骤，返回取消后的权威快照。
  const response = await request(`/api/digital-human/agent/runs/${encodeURIComponent(runId)}/cancel`, { method: 'POST' });
  return readJson<DigitalHumanAgentRun>(response);
}

export async function getDigitalHumanAgentRun(runId: string): Promise<DigitalHumanAgentRun> {
  const response = await request(`/api/digital-human/agent/runs/${encodeURIComponent(runId)}`);
  return readJson(response);
}

export async function createDigitalHumanMatter(
  goal: string,
  sessionId?: string | null,
  expectedVersion = 0,
  idempotencyKey?: string,
): Promise<{
  matter_id: string;
  session_id: string | null;
  title: string;
  goal: string;
  workspace: DigitalHumanWorkspaceContext | null;
}> {
  const response = await request('/api/digital-human/agent/matters', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Idempotency-Key': idempotencyKey || `dhm_${crypto.randomUUID()}`,
    },
    body: JSON.stringify({
      goal,
      expected_version: expectedVersion,
      ...(sessionId ? { session_id: sessionId } : {}),
    }),
  });
  return readJson(response);
}

export async function confirmMatterJurisdiction(matterId: string, subdivisionCode: string): Promise<void> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/jurisdiction`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      country_code: 'CN', subdivision_code: subdivisionCode || null,
      effective_at: new Date().toISOString(), confirmed_by_user: true,
    }),
  });
  await readJson(response);
}

export async function addMatterMaterial(
  matterId: string, filename: string, text: string, mediaType = 'text/plain',
): Promise<MatterMaterial> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/materials`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename, text, media_type: mediaType }),
  });
  return readJson(response);
}

export async function organizeMatterMaterial(
  matterId: string, file: File,
): Promise<OrganizedMatterMaterial> {
  const body = new FormData();
  body.append('file', file);
  const response = await request(
    `/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/materials/organize`,
    { method: 'POST', body },
    180000,
  );
  return (await readJson<{ material: OrganizedMatterMaterial }>(response)).material;
}

export async function analyzeMatterMaterial(
  matterId: string, documentId: string,
): Promise<MatterAnalysisResult> {
  const base = `/api/digital-human/agent/matters/${encodeURIComponent(matterId)}`;
  const factsResponse = await request(`${base}/materials/${encodeURIComponent(documentId)}/facts`, { method: 'POST' });
  const facts = (await readJson<{ facts: LocatedLegalFact[] }>(factsResponse)).facts;
  const [timelineResponse, checklistResponse] = await Promise.all([
    request(`${base}/timeline`), request(`${base}/evidence-checklist`),
  ]);
  const timeline = (await readJson<{ timeline: MatterAnalysisResult['timeline'] }>(timelineResponse)).timeline;
  const checklist = await readJson<MatterAnalysisResult['checklist']>(checklistResponse);
  return { facts, timeline, checklist };
}

export async function getDigitalHumanMatters(): Promise<DigitalHumanMatterSummary[]> {
  const response = await request('/api/digital-human/agent/matters');
  return (await readJson<{ matters: DigitalHumanMatterSummary[] }>(response)).matters;
}

export async function deleteDigitalHumanMatter(matterId: string): Promise<void> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}`, { method: 'DELETE' });
  await readJson(response);
}

export async function getDigitalHumanMatter(matterId: string): Promise<DigitalHumanMatterDetail> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}`);
  return readJson(response);
}

export async function calculateMatterLaborCompensation(
  matterId: string, monthlySalary: number, years: number, months: number,
): Promise<LaborCompensationResult> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/tools/labor-compensation`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ monthly_salary: monthlySalary, years, months }),
  });
  return (await readJson<{ data: LaborCompensationResult }>(response)).data;
}

export async function updateLaborDisputeFacts(
  matterId: string, facts: Record<string, unknown>,
): Promise<LaborDisputeWorkflow> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute/facts`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(facts),
  });
  return readJson(response);
}

export async function getLaborDisputeWorkflow(matterId: string): Promise<LaborDisputeWorkflow> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute`);
  return readJson(response);
}

export async function analyzeLaborDispute(matterId: string): Promise<LaborDisputeWorkflow> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute/analyze`, { method: 'POST' });
  return readJson(response);
}

export async function createLaborDisputeDraft(matterId: string): Promise<LaborDisputeDraft> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute/draft`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ approved: true }),
  });
  return readJson(response);
}

export async function startLaborDisputeAgentRun(
  matterId: string, facts: Record<string, unknown>,
  taskType:
    | 'cn_labor_dispute' | 'labor_arbitration_application'
    | 'labor_consultation' | 'labor_case_analysis' | 'labor_relationship_assessment'
    = 'cn_labor_dispute',
): Promise<DigitalHumanAgentRun> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute/run`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ facts, task_type: taskType }),
  });
  return readJson(response);
}

export async function continueLaborDisputeAgentRun(
  runId: string, action: 'provide_information' | 'confirm_jurisdiction' | 'approve' | 'retry_authority',
  payload: Record<string, unknown> = {},
): Promise<DigitalHumanAgentRun> {
  const response = await request(`/api/digital-human/agent/runs/${encodeURIComponent(runId)}/continue`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
    body: JSON.stringify({ action, payload }),
  });
  return readJson(response);
}

export async function getLaborDisputeFactSuggestions(matterId: string): Promise<LaborFactSuggestions> {
  const response = await request(`/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor-dispute/suggestions`);
  return readJson(response);
}

export async function getLaborCaseTriage(matterId: string): Promise<LaborTriageSnapshot> {
  const response = await request(
    `/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor/triage`,
  );
  return readJson(response);
}

export async function updateLaborCaseTriage(
  matterId: string,
  facts: Partial<LaborTriageFacts>,
): Promise<LaborTriageSnapshot> {
  const response = await request(
    `/api/digital-human/agent/matters/${encodeURIComponent(matterId)}/labor/triage`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(facts),
    },
  );
  return readJson(response);
}

export async function getLaborAuthorityCatalog(): Promise<LaborAuthorityCatalog> {
  const response = await request('/api/digital-human/agent/legal-authorities/labor');
  return readJson(response);
}
