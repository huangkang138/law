// API 调用封装

const API_BASE_URL = `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8001'}/api`;

// 风险等级枚举
export enum RiskLevel {
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW'
}

// 合同审查响应类型
export interface ContractReviewResponse {
  success: boolean;
  overall_summary: string;
  risks: {
    risk_level: RiskLevel;
    original_clause: string;
    original_text_quote?: string;
    risk_explanation: string;
    legal_basis: string[];
    legal_basis_links?: string[];
    revise_suggestion: string;
    confidence_score: number;
  }[];
  is_image_based: boolean;
  processing_steps?: string[];
}

// 发送聊天消息
export const sendChatMessage = async (data: {
  question: string;
  session_id: string;
}) => {
  const response = await fetch(`${API_BASE_URL}/legal/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '处理您的请求时出现错误');
  }

  return await response.json();
};

// 上传文档
export const uploadDocument = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(`${API_BASE_URL}/document/upload`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '处理您的请求时出现错误');
  }

  return await response.json();
};

// 合同审查
export const reviewContract = async (contractId: string) => {
  const response = await fetch(`${API_BASE_URL}/document/review`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ contract_id: contractId }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '处理您的请求时出现错误');
  }

  return await response.json() as ContractReviewResponse;
};

// 启动合同审查流式输出
export const startContractReviewStream = async (contractId?: string, content?: string) => {
  const response = await fetch(`${API_BASE_URL}/document/review/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ contract_id: contractId, content: content }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '处理您的请求时出现错误');
  }

  return await response.json();
};

// 获取合同审查流式输出
export const getContractReviewStream = (sessionId: string) => {
  const eventSource = new EventSource(`${API_BASE_URL}/document/review/stream/${sessionId}`);
  return eventSource;
};

// 模拟法庭
export const startDebate = async (data: {
  case_description: string;
  plaintiff_arguments: string;
  defendant_arguments: string;
}) => {
  const response = await fetch(`${API_BASE_URL}/analysis/debate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '处理您的请求时出现错误');
  }

  return await response.json();
};

// 获取普法问答历史记录
export const getLegalChatHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/legal/sessions`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取历史记录失败');
  }

  return await response.json();
};

// 获取普法问答会话详情
export const getLegalChatSessionDetails = async (sessionId: string) => {
  const response = await fetch(`${API_BASE_URL}/legal/sessions/${sessionId}/messages`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取会话详情失败');
  }

  return await response.json();
};

// 删除普法问答会话
export const deleteLegalChatSession = async (sessionId: string) => {
  const response = await fetch(`${API_BASE_URL}/legal/sessions/${sessionId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '删除会话失败');
  }

  return await response.json();
};

// 更新普法问答会话标题
export const updateLegalChatSessionTitle = async (sessionId: string, title: string) => {
  const response = await fetch(`${API_BASE_URL}/legal/sessions/${sessionId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '更新会话标题失败');
  }

  return await response.json();
};

// 获取合同审查历史记录
export const getContractHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/document/history`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取历史记录失败');
  }

  return await response.json();
};

// 获取合同审查详情
export const getContractDetails = async (contractId: string) => {
  const response = await fetch(`${API_BASE_URL}/document/${contractId}/details`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取合同详情失败');
  }

  return await response.json();
};

// 删除合同审查记录
export const deleteContract = async (contractId: string) => {
  const response = await fetch(`${API_BASE_URL}/document/${contractId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '删除合同失败');
  }

  return await response.json();
};

// 更新合同文件名
export const updateContractFilename = async (contractId: string, filename: string) => {
  const response = await fetch(`${API_BASE_URL}/document/${contractId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ filename }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '更新合同文件名失败');
  }

  return await response.json();
};

// 获取模拟法庭历史记录
export const getDebateHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/debate/history`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取历史记录失败');
  }

  return await response.json();
};

// 获取模拟法庭详情
export const getDebateDetails = async (sessionId: string) => {
  const response = await fetch(`${API_BASE_URL}/debate/${sessionId}/full-details`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取庭审详情失败');
  }

  return await response.json();
};

// 删除模拟法庭会话
export const deleteDebateSession = async (sessionId: string) => {
  const response = await fetch(`${API_BASE_URL}/debate/${sessionId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '删除庭审会话失败');
  }

  return await response.json();
};

// 更新模拟法庭会话标题
export const updateDebateSessionTitle = async (sessionId: string, title: string) => {
  const response = await fetch(`${API_BASE_URL}/debate/${sessionId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '更新庭审标题失败');
  }

  return await response.json();
};

// 获取案情推断历史记录
export const getCaseAnalysisHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/analysis/case-analysis/history`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取案情推断历史记录失败');
  }

  return await response.json();
};

// 获取相似文书搜索历史记录
export const getSimilarDocumentHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/analysis/similar-documents/history`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '获取相似文书搜索历史记录失败');
  }

  return await response.json();
};

// 删除案情推断记录
export const deleteCaseAnalysis = async (analysisId: string) => {
  const response = await fetch(`${API_BASE_URL}/analysis/case-analysis/${analysisId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '删除案情推断记录失败');
  }

  return await response.json();
};

// 删除相似文书搜索记录
export const deleteSimilarDocument = async (searchId: string) => {
  const response = await fetch(`${API_BASE_URL}/analysis/similar-documents/${searchId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      detail: 'API 请求失败',
    }));
    throw new Error(error.detail || '删除相似文书搜索记录失败');
  }

  return await response.json();
};

// ==================== 纠纷处理相关API ====================

// 纠纷信息整理（文字输入）
export const organizeDispute = async (data: { input_content: string; input_type?: string }) => {
  const response = await fetch(`${API_BASE_URL}/dispute/organize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '纠纷信息整理失败');
  }

  return await response.json();
};

// 纠纷信息整理（文件上传）
export const organizeDisputeWithFiles = async (formData: FormData) => {
  const response = await fetch(`${API_BASE_URL}/dispute/organize`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '纠纷信息整理失败');
  }

  return await response.json();
};

// 获取纠纷信息历史记录
export const getDisputeHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/dispute/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取纠纷信息历史记录失败');
  }

  return await response.json();
};

// 删除纠纷信息记录
export const deleteDispute = async (disputeId: string) => {
  const response = await fetch(`${API_BASE_URL}/dispute/${disputeId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除纠纷信息记录失败');
  }

  return await response.json();
};

// 取证存证
export const collectEvidence = async (data: { 
  dispute_id: string; 
  evidence_name: string; 
  evidence_type: string; 
  evidence_content?: string 
}) => {
  const response = await fetch(`${API_BASE_URL}/evidence/collect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '取证存证失败');
  }

  return await response.json();
};

// 获取取证存证历史记录
export const getEvidenceHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/evidence/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取取证存证历史记录失败');
  }

  return await response.json();
};

// 删除取证存证记录
export const deleteEvidence = async (evidenceId: string) => {
  const response = await fetch(`${API_BASE_URL}/evidence/${evidenceId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除取证存证记录失败');
  }

  return await response.json();
};

// 维权路径规划
export const planProtection = async (data: { dispute_id: string }) => {
  const response = await fetch(`${API_BASE_URL}/protection/plan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '维权路径规划失败');
  }

  return await response.json();
};

// 获取维权路径规划历史记录
export const getProtectionHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/protection/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取维权路径规划历史记录失败');
  }

  return await response.json();
};

// 删除维权路径规划记录
export const deleteProtection = async (pathId: string) => {
  const response = await fetch(`${API_BASE_URL}/protection/${pathId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除维权路径规划记录失败');
  }

  return await response.json();
};

// 法律文书生成
export const generateDocument = async (data: { dispute_id: string; document_type: string }) => {
  const response = await fetch(`${API_BASE_URL}/document/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '法律文书生成失败');
  }

  return await response.json();
};

// 获取法律文书历史记录
export const getDocumentHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/document/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取法律文书历史记录失败');
  }

  return await response.json();
};

// 删除法律文书记录
export const deleteLegalDocument = async (documentId: string) => {
  const response = await fetch(`${API_BASE_URL}/document/${documentId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除法律文书记录失败');
  }

  return await response.json();
};

// 案件预判分析
export const analyzePrediction = async (data: { dispute_id: string }) => {
  const response = await fetch(`${API_BASE_URL}/prediction/analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '案件预判分析失败');
  }

  return await response.json();
};

// 获取案件预判历史记录
export const getPredictionHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/prediction/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取案件预判历史记录失败');
  }

  return await response.json();
};

// 删除案件预判记录
export const deletePrediction = async (predictionId: string) => {
  const response = await fetch(`${API_BASE_URL}/prediction/${predictionId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除案件预判记录失败');
  }

  return await response.json();
};

// 创建案件流程提醒
export const createReminder = async (data: { dispute_id: string }) => {
  const response = await fetch(`${API_BASE_URL}/reminder/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '创建案件流程提醒失败');
  }

  return await response.json();
};

// 获取案件流程提醒历史记录
export const getReminderHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/reminder/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取案件流程提醒历史记录失败');
  }

  return await response.json();
};

// 删除案件流程提醒记录
export const deleteReminder = async (reminderId: string) => {
  const response = await fetch(`${API_BASE_URL}/reminder/${reminderId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除案件流程提醒记录失败');
  }

  return await response.json();
};

// 避坑提醒分析
export const analyzeWarning = async (data: { dispute_id: string }) => {
  const response = await fetch(`${API_BASE_URL}/warning/analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '避坑提醒分析失败');
  }

  return await response.json();
};

// 获取避坑提醒历史记录
export const getWarningHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/warning/history`, { method: 'GET' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取避坑提醒历史记录失败');
  }

  return await response.json();
};

// 删除避坑提醒记录
export const deleteWarning = async (warningId: string) => {
  const response = await fetch(`${API_BASE_URL}/warning/${warningId}`, { method: 'DELETE' });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除避坑提醒记录失败');
  }

  return await response.json();
};

// 获取相似案件搜索历史记录
export const getCaseSearchHistory = async () => {
  const response = await fetch(`${API_BASE_URL}/case/history`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取相似案件搜索历史记录失败');
  }

  return await response.json();
};

// 获取相似案件搜索历史详情
export const getCaseSearchHistoryDetail = async (searchId: string) => {
  const response = await fetch(`${API_BASE_URL}/case/history/${searchId}`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取相似案件搜索历史详情失败');
  }

  return await response.json();
};

// 删除相似案件搜索历史记录
export const deleteCaseSearchHistory = async (searchId: string) => {
  const response = await fetch(`${API_BASE_URL}/case/history/${searchId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除相似案件搜索历史记录失败');
  }

  return await response.json();
};

// ==================== 收藏相关API ====================

// 获取所有收藏
export const getFavorites = async () => {
  const response = await fetch(`${API_BASE_URL}/favorites`, {
    method: 'GET',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '获取收藏列表失败');
  }

  return await response.json();
};

// 创建收藏
export const createFavorite = async (data: {
  title: string;
  content: string;
  source_type: string;
  source_id?: string;
}) => {
  const response = await fetch(`${API_BASE_URL}/favorites`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '创建收藏失败');
  }

  return await response.json();
};

// 删除收藏
export const deleteFavorite = async (favoriteId: string) => {
  const response = await fetch(`${API_BASE_URL}/favorites/${favoriteId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '删除收藏失败');
  }

  return await response.json();
};

// 更新收藏标题
export const updateFavoriteTitle = async (favoriteId: string, title: string) => {
  const response = await fetch(`${API_BASE_URL}/favorites/${favoriteId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'API 请求失败' }));
    throw new Error(error.detail || '更新收藏标题失败');
  }

  return await response.json();
};