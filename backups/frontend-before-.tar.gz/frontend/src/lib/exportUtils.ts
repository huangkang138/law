import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export interface ExportOptions {
  title?: string;
  filename?: string;
}

const cleanMarkdown = (markdown: string): string => {
  let cleaned = markdown;
  
  cleaned = cleaned.replace(/\r\n/g, '\n');
  
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
  
  cleaned = cleaned.replace(/[ \t]+\n/g, '\n');
  
  cleaned = cleaned.replace(/^[ \t]+/gm, (match) => {
    if (match.length <= 2) return match;
    return '  ';
  });
  
  cleaned = cleaned.replace(/^---+$/gm, '');
  
  cleaned = cleaned.replace(/^-{3,}\s*$/gm, '');

  
  
  cleaned = cleaned.trim();
  
  cleaned = removeAIIntroduction(cleaned);
  
  return cleaned;
};

const removeAIIntroduction = (content: string): string => {
  const lines = content.split('\n');
  let startIndex = 0;
  
  const aiIntroPatterns = [
    /^(好的|好的，|作为一名|作为|我是|我将|根据您|根据您提供)/,
    /^(请注意|请注意，|本模型生成的内容不构成|对于涉及|建议您咨询|建议您)/,
    /^(以下是为您|为您草拟|为您生成|为您准备)/,
    /^(好的，我将|好的，作为一名|好的，根据)/,
    /^(我将根据|我将为您|我将为您草拟)/,
    /^(根据您的需求|根据您提供的需求)/,
    /^(AI|模型|助手|智能)/,
  ];
  
  let inAIIntro = true;
  let consecutiveNonAI = 0;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    if (!line) {
      if (inAIIntro && consecutiveNonAI > 0) {
        startIndex = i + 1;
        break;
      }
      continue;
    }
    
    const isAIIntro = aiIntroPatterns.some(pattern => pattern.test(line));
    
    if (isAIIntro) {
      consecutiveNonAI = 0;
    } else {
      consecutiveNonAI++;
      if (consecutiveNonAI >= 2) {
        startIndex = i - 1;
        break;
      }
    }
  }
  
  const resultLines = lines.slice(startIndex);
  return resultLines.join('\n').trim();
};

export const exportAsImage = async (content: string, options: ExportOptions = {}): Promise<void> => {
  try {
    const container = document.createElement('div');
    container.style.cssText = `
      position: absolute;
      left: -9999px;
      top: 0;
      width: 800px;
      padding: 48px;
      background: linear-gradient(135deg, #fefce8 0%, #fef3c7 50%, #fde68a 100%);
      font-family: 'Microsoft YaHei', 'SimSun', Arial, sans-serif;
      font-size: 15px;
      line-height: 1.8;
      color: #1f2937;
      border-radius: 16px;
    `;
    
    const titleDiv = document.createElement('div');
    titleDiv.style.cssText = `
      font-size: 24px;
      font-weight: bold;
      color: #92400e;
      margin-bottom: 24px;
      padding-bottom: 16px;
      border-bottom: 2px solid #f59e0b;
      text-align: center;
    `;
    titleDiv.textContent = options.title || '法律文书';
    container.appendChild(titleDiv);
    
    const contentDiv = document.createElement('div');
    contentDiv.innerHTML = convertMarkdownToHtml(cleanMarkdown(content));
    container.appendChild(contentDiv);
    
    document.body.appendChild(container);

    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#fefce8',
    });

    document.body.removeChild(container);

    const link = document.createElement('a');
    const filename = options.filename || options.title || 'document';
    link.download = `${filename}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  } catch (error) {
    console.error('导出图片失败:', error);
    throw error;
  }
};

export const exportAsPDF = async (content: string, options: ExportOptions = {}): Promise<void> => {
  try {
    const container = document.createElement('div');
    container.style.cssText = `
      position: absolute;
      left: -9999px;
      top: 0;
      width: 800px;
      padding: 48px;
      background: #ffffff;
      font-family: 'Microsoft YaHei', 'SimSun', Arial, sans-serif;
      font-size: 14px;
      line-height: 1.8;
      color: #1f2937;
    `;
    
    const titleDiv = document.createElement('div');
    titleDiv.style.cssText = `
      font-size: 22px;
      font-weight: bold;
      color: #92400e;
      margin-bottom: 20px;
      padding-bottom: 12px;
      border-bottom: 2px solid #f59e0b;
      text-align: center;
    `;
    titleDiv.textContent = options.title || '法律文书';
    container.appendChild(titleDiv);
    
    const contentDiv = document.createElement('div');
    contentDiv.innerHTML = convertMarkdownToHtml(cleanMarkdown(content));
    container.appendChild(contentDiv);
    
    document.body.appendChild(container);

    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
    });

    document.body.removeChild(container);

    const imgWidth = 210;
    const pageHeight = 297;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;

    const pdf = new jsPDF('p', 'mm', 'a4');
    let position = 0;

    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const filename = options.filename || options.title || 'document';
    pdf.save(`${filename}.pdf`);
  } catch (error) {
    console.error('导出PDF失败:', error);
    throw error;
  }
};

export const exportAsWord = async (content: string, options: ExportOptions = {}): Promise<void> => {
  try {
    const filename = options.filename || options.title || 'document';
    const cleanedContent = cleanMarkdown(content);
    const htmlContent = convertMarkdownToHtml(cleanedContent);
    
    const wordContent = `
      <!DOCTYPE html>
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${options.title || 'Document'}</title>
        <style>
          @page {
            size: A4;
            margin: 2.54cm;
          }
          body {
            font-family: 'Microsoft YaHei', 'SimSun', Arial, sans-serif;
            font-size: 12pt;
            line-height: 1.8;
            color: #333;
            margin: 0;
            padding: 0;
          }
          .document-container {
            max-width: 100%;
            margin: 0 auto;
          }
          h1 { 
            font-size: 18pt; 
            font-weight: bold;
            margin-bottom: 12pt; 
            color: #92400e;
            text-align: center;
            border-bottom: 2pt solid #f59e0b;
            padding-bottom: 8pt;
            page-break-after: avoid;
          }
          h2 { 
            font-size: 16pt; 
            font-weight: bold;
            margin-bottom: 10pt;
            margin-top: 16pt;
            color: #92400e;
            page-break-after: avoid;
          }
          h3 { 
            font-size: 14pt; 
            font-weight: bold;
            margin-bottom: 8pt;
            margin-top: 12pt;
            color: #92400e;
            page-break-after: avoid;
          }
          p { 
            margin-bottom: 8pt;
            margin-top: 0;
            text-align: left;
            line-height: 1.8;
          }
          ul, ol { 
            margin-left: 20pt; 
            margin-bottom: 8pt;
            margin-top: 8pt;
          }
          li { 
            margin-bottom: 4pt;
            line-height: 1.8;
          }
          table { 
            border-collapse: collapse; 
            width: 100%; 
            margin-bottom: 12pt;
            margin-top: 12pt;
          }
          th, td { 
            border: 1px solid #ddd; 
            padding: 8pt; 
            text-align: left;
            vertical-align: top;
          }
          th { 
            background-color: #f5f5f5;
            font-weight: bold;
          }
          code { 
            background-color: #f5f5f5; 
            padding: 2pt 4pt; 
            border-radius: 2pt; 
            font-family: Consolas, monospace;
            font-size: 10pt;
          }
          pre { 
            background-color: #f5f5f5; 
            padding: 12pt; 
            border-radius: 4pt; 
            overflow-x: auto;
            font-family: Consolas, monospace;
            font-size: 10pt;
            line-height: 1.5;
          }
          blockquote { 
            border-left: 3pt solid #f59e0b; 
            margin-left: 0; 
            padding-left: 12pt; 
            color: #666; 
            font-style: italic;
            margin-bottom: 8pt;
          }
          strong {
            color: #92400e;
            font-weight: bold;
          }
          em {
            font-style: italic;
          }
          br {
            line-height: 1.8;
          }
        </style>
      </head>
      <body>
        <div class="document-container">
          <h1>${options.title || '法律文书'}</h1>
          ${htmlContent}
        </div>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', wordContent], {
      type: 'application/msword'
    });

    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}.doc`;
    link.click();
    URL.revokeObjectURL(link.href);
  } catch (error) {
    console.error('导出Word失败:', error);
    throw error;
  }
};

const convertMarkdownToHtml = (markdown: string): string => {
  let html = markdown;

  html = html.replace(/^#{3}\s+(.*$)/gim, '<h3>$1</h3>');
  html = html.replace(/^#{2}\s+(.*$)/gim, '<h2>$1</h2>');
  html = html.replace(/^#{1}\s+(.*$)/gim, '<h1>$1</h1>');

  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  html = html.replace(/^>\s+(.*$)/gim, '<blockquote>$1</blockquote>');

  html = html.replace(/^[\-\*]\s+(.*$)/gim, '<li>$1</li>');
  html = html.replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>');

  html = html.replace(/^\d+\.\s+(.*$)/gim, '<li>$1</li>');

  html = html.replace(/\n\n/g, '</p><p>');
  html = html.replace(/\n/g, '<br>');
  
  html = `<p>${html}</p>`;

  html = html.replace(/<p><h([1-6])>/g, '<h$1>');
  html = html.replace(/<\/h([1-6])><\/p>/g, '</h$1>');
  html = html.replace(/<p><ul>/g, '<ul>');
  html = html.replace(/<\/ul><\/p>/g, '</ul>');
  html = html.replace(/<p><blockquote>/g, '<blockquote>');
  html = html.replace(/<\/blockquote><\/p>/g, '</blockquote>');
  html = html.replace(/<p><ol>/g, '<ol>');
  html = html.replace(/<\/ol><\/p>/g, '</ol>');

  html = html.replace(/<p>\s*<br\s*\/?>/g, '<p>');
  html = html.replace(/<br\s*\/?>\s*<\/p>/g, '</p>');
  html = html.replace(/<p>\s*<\/p>/g, '');

  html = html.replace(/<p>\s*<h([1-6])>/g, '<h$1>');
  html = html.replace(/<h([1-6])>\s*<\/p>/g, '</h$1>');
  html = html.replace(/<p>\s*<ul>/g, '<ul>');
  html = html.replace(/<ul>\s*<\/p>/g, '</ul>');
  html = html.replace(/<p>\s*<ol>/g, '<ol>');
  html = html.replace(/<ol>\s*<\/p>/g, '</ol>');
  html = html.replace(/<p>\s*<blockquote>/g, '<blockquote>');
  html = html.replace(/<blockquote>\s*<\/p>/g, '</blockquote>');

  html = html.replace(/<p>\s*<li>/g, '<li>');
  html = html.replace(/<li>\s*<\/p>/g, '</li>');

  html = html.replace(/\s*<br\s*\/?>\s*/g, '<br>');
  html = html.replace(/<br\s*\/?>\s*<br\s*\/?>/g, '<br>');

  html = html.replace(/<p>\s*<p>/g, '<p>');
  html = html.replace(/<\/p>\s*<\/p>/g, '</p>');

  html = html.replace(/<p>\s*<\/p>/g, '');

  return html;
};
